# Review notes

## Review fixture — video

<http://127.0.0.1:4173/video.html>

### #1 · visual · open · 00:03.00

- id: `0mwew4wjmc02ytc7n`
- adapter: html5-video
- annotation: 3 shape(s) (box, arrow, text) on media

> Logo is too small and too close to the edge

![note 1](screenshots/0mwew4wjmc02ytc7n.png)
